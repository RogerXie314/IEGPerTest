WLServerTest V6.1
===================

版本: V6.1
日期: 2026-05-25
Git标签: v6.1

主要修复:
---------
1. 攻击报文多stream加载问题修复
   - MS17-010和MS20-796现在能正确加载所有streams
   - 左侧显示3个攻击类型，右侧发送时显示实际stream数量
   - 确保攻击检测完整性

2. 编码问题修复
   - 修复GBK编码导致的编译错误
   - 界面文字已英文化

包含文件:
---------
- WLServerTest.exe         主程序
- WLNetComm.dll           网络通信库
- RawPacketEngine.dll     攻击报文引擎
- WLServerTest.ini        配置文件

系统要求:
---------
- Windows 7/8/10/11 (64位)
- Microsoft Visual C++ Redistributable 2015-2022
- Npcap (攻击报文功能需要，从 https://npcap.com 下载)

使用说明:
---------
1. 解压所有文件到同一目录
2. 如需攻击报文功能，先安装Npcap
3. 双击WLServerTest.exe运行
4. 点击"攻击报文"按钮测试修复

测试验证:
---------
1. 打开攻击报文对话框
2. 勾选MS17-010或MS20-796
3. 点击开始发送
4. 右侧应显示2个streams（带#1、#2编号）

技术支持:
---------
GitHub: https://github.com/RogerXie314/IEGPerTest
版本: v6.1

注意: 攻击报文功能仅供合法安全测试使用。